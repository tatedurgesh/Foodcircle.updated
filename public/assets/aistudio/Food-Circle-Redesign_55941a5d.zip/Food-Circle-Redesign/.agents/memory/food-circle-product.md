---
name: Food Circle product scope
description: Product positioning and content guardrails for the Food Circle consultancy website.
---

Food Circle is a food safety and compliance consultancy supporting food businesses in Mumbai, Maharashtra, India. Public-facing copy should use Food Circle as the organization identity, not a named consultant. Use only supplied services and credentials. Avoid unsupported performance claims, invented clients or reviews, fabricated affiliations or accreditations, guarantees, and an office or residential address.

**Why:** The user specified these accuracy and identity constraints for the business website.

**How to apply:** Follow these constraints when adding or revising Food Circle website copy and local search content.
